<div class="form-group">
    <label style="font-size:1.1rem" class="mb-3" for="<?php echo e($question->key); ?>"><?php echo e($question->content); ?></label>
    <?php echo e($slot); ?>

    <?php if($errors->has($question->key)): ?>
        <div class="text-danger mt-3"><?php echo e($errors->first($question->key)); ?></div>
    <?php endif; ?>
</div>

<div class="text-success">
    <?php echo e($report ?? ''); ?>    
</div>
<?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/questions/base.blade.php ENDPATH**/ ?>