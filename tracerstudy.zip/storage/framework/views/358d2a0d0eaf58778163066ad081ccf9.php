<?php $__env->startComponent('survey::questions.base', compact('question')); ?>
    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="custom-control custom-checkbox">
            <input type="checkbox"
                   name="<?php echo e($question->key); ?>[]"
                   id="<?php echo e($question->key . '-' . Str::slug($option)); ?>"
                   value="<?php echo e($option); ?>"
                   class="custom-control-input"
                    <?php echo e(($value ?? old($question->key)) == $option ? 'checked' : ''); ?>

                    <?php echo e(($disabled ?? false) ? 'disabled' : ''); ?>

            >
            <label class="custom-control-label"
                   for="<?php echo e($question->key . '-' . Str::slug($option)); ?>"><?php echo e($option); ?>

            </label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/questions/types/multiselect.blade.php ENDPATH**/ ?>