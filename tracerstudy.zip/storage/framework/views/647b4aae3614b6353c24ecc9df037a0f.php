<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve(['title' => 'Isi Survei'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-dark bg-white m-auto pb-4" style="width: 500px; z-index: 999">
        <h1 class="h5 text-center py-4 bg-primary m-0 text-white"><?php echo e($survey->name); ?> | SMKN 1 POGALAN</h1>
        <form method="POST" action="" autocomplete="off" x-data="{SaatIni: []}">
            <?php echo csrf_field(); ?>
            <div class="py-4 px-5">
                <?php if($errors->any()): ?>
                <div class="alert alert-info"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
                <div>
                    <label class="col-form-label"><?php echo e($primary_option->content); ?> <span class="text-danger">*</span></label>
                    <?php $__currentLoopData = $primary_option->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="<?php echo e($option); ?>" name="q<?php echo e($primary_option->id); ?>[]" id="input-<?php echo e($option); ?>" x-model="SaatIni">
                        <label class="form-check-label" for="input-<?php echo e($option); ?>">
                            <?php echo e($option); ?>

                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        
           <?php $__currentLoopData = $survey->questions()->whereNot('id', 1)->whereHas('section')->with('section')->get()->groupBy('section.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div x-show="SaatIni.includes('<?php echo e($section); ?>')">
            <h1 class="h5 py-3 px-3 bg-primary mt-4 m-0 text-white">Kegiatan: <b><?php echo e($section); ?></b></h1>
            <div class="px-5">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label class="col-form-label"><?php echo e($question->content); ?> <span class="text-danger">*</span></label>
                        <?php if($question->type == 'text'): ?>
                        <input type="text" class="form-control" name="q<?php echo e($question->id); ?>">

                        <?php elseif($question->type == 'multiselect'): ?>
                        <select class="form-select" name="q<?php echo e($question->id); ?>">
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php elseif($question->type == 'multiselect'): ?>
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="<?php echo e($option); ?>" name="q<?php echo e($question->id); ?>" id="input-<?php echo e($option); ?>">
                                <label class="form-check-label" for="input-<?php echo e($option); ?>">
                                    <?php echo e($option); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php elseif($question->type == 'radio'): ?>
                        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" value="<?php echo e($option); ?>" name="q<?php echo e($question->id); ?>">
                            <label class="form-check-label">
                                <?php echo e($option); ?>

                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
            <div class="px-5">        
                <button type="submit" class="btn btn-primary w-100 mt-4">SIMPAN !</button>
            </div>

        </form>
        <footer class="text-center mt-2" style="opacity: .52; font-size:15px">2024 - SMKN 1 Pogalan | <a href="//fb.me/SHeSHeOrankZ" class="text-dark" target="_blank">L-155-4</a></footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\tracerstudy\resources\views/survey.blade.php ENDPATH**/ ?>