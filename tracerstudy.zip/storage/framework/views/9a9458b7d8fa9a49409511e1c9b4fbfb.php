<?php $__env->startComponent('survey::questions.base', compact('question')); ?>
    <input type="text" name="<?php echo e($question->key); ?>" id="<?php echo e($question->key); ?>" class="form-control"
           value="<?php echo e($value ?? old($question->key)); ?>" <?php echo e(($disabled ?? false) ? 'disabled' : ''); ?>>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/questions/types/text.blade.php ENDPATH**/ ?>