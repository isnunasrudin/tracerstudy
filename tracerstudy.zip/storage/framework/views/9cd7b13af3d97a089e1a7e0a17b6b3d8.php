<div class="card">
    <div class="card-header bg-white p-4">
        <h2 class="mb-0"><?php echo e($survey->name); ?></h2>

        <?php if(!$eligible): ?>
            We only accept
            <strong><?php echo e($survey->limitPerParticipant()); ?> <?php echo e(\Str::plural('entry', $survey->limitPerParticipant())); ?></strong>
            per participant.
        <?php endif; ?>

        <?php if($lastEntry): ?>
            You last submitted your answers <strong><?php echo e($lastEntry->created_at->diffForHumans()); ?></strong>.
        <?php endif; ?>

    </div>
    <?php if(!$survey->acceptsGuestEntries() && auth()->guest()): ?>
        <div class="p-5">
            Please login to join this survey.
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $survey->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('survey::sections.single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $survey->questions()->withoutSection()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('survey::questions.single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($eligible): ?>
            <button class="btn btn-primary">Submit</button>
        <?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/standard.blade.php ENDPATH**/ ?>