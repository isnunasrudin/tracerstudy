<div class="p-4 border-bottom">
    <?php echo $__env->make(view()->exists("survey::questions.types.{$question->type}") 
        ? "survey::questions.types.{$question->type}" 
        : "survey::questions.types.text",[
            'disabled' => !($eligible ?? true), 
            'value' => $lastEntry ? $lastEntry->answerFor($question) : null,
            'includeResults' => ($lastEntry ?? null) !== null
        ]
    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/questions/single.blade.php ENDPATH**/ ?>