<?php $__env->startComponent('survey::questions.base', compact('question')); ?>
    <input type="number" name="<?php echo e($question->key); ?>" id="<?php echo e($question->key); ?>" class="form-control"
           value="<?php echo e($value ?? old($question->key)); ?>" <?php echo e(($disabled ?? false) ? 'disabled' : ''); ?>>
    
    <?php $__env->slot('report'); ?>
        <?php if($includeResults ?? false): ?>
            <?php echo e(number_format((new \MattDaneshvar\Survey\Utilities\Summary($question))->average())); ?> (Average)
        <?php endif; ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laragon\www\tracerstudy\vendor\matt-daneshvar\laravel-survey\src/../resources/views/questions/types/number.blade.php ENDPATH**/ ?>