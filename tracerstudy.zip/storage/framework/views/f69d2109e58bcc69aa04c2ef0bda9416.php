<!-- <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survei</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

</head>
<body>
    <form action="" method="POST">    
        <?php echo $__env->make('survey::standard', ['survey' => $survey], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
</body>
</html> -->

<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve(['title' => 'Masuk'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="m-auto pb-4" style="width: 500px; z-index: 999">
        <h1 class="h5 text-center py-4 bg-primary m-0">Tracer Study Berdaya</h1>
        <form class="p-5 pt-4 bg-white text-dark" method="POST" action="" autocomplete="off">
            <?php if($errors->any()): ?>
            <div class="alert alert-info"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>
            <div>
                <label class="col-form-label">Nomor Induk Siswa Nasional <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="nisn" required value="<?php echo e(old('nisn')); ?>">
            </div>
            <?php echo csrf_field(); ?>
            <div>
                <label class="col-form-label mt-3">Tanggal Lahir <span class="text-danger">*</span></label>
                <input type="date" class="form-control" name="born_date" max="2008-12-31" required value="<?php echo e(old('born_date')); ?>">
            </div>
            <div>
                <label class="col-form-label mt-3">No. WhatsApp <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="phone" required value="<?php echo e(old('phone')); ?>">
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-4">MASUK!</button>
        </form>
        <footer class="text-center mt-2" style="opacity: .22; font-size:15px">2024 - SMKN 1 Pogalan | <a href="//fb.me/SHeSHeOrankZ" class="text-white" target="_blank">L-155-4</a></footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\tracerstudy\resources\views/welcome.blade.php ENDPATH**/ ?>